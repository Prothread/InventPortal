<?php
/**
 *
 * Database definition file.
 *
 * @author Kevin Ernst
 * @version 0.1
 */

/* Database inlog gegevens */
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "portalinvent");



define("TXT_NO_DATA", "Geen gegevens gevonden.");
